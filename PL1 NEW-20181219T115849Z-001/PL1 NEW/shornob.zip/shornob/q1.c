#include <stdio.h>
int main()

{
    int i,j ,b;
    printf( " Enter array size :");
    scanf( "%d",&b);
    int a[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);
    }
    for(j=b ; j>0; j-- )
    {
        printf( "%d  " ,a[j-1]);
    }

    return 0;





}

