#include <stdio.h>
int main()

{
    int i,j ,b ,sum = 0;

    printf( " Enter array size :");
    scanf( "%d",&b);
    int a[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);
    }
    for(j=b ; j>0; j-- )
    {
       sum = sum + a[ j-1];
    }
    printf( " Result : %d" ,sum);

    return 0;





}


