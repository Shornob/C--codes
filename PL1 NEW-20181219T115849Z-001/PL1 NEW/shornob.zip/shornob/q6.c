#include <stdio.h>
int main()

{
    int i,j ,b,d ,count = 0 , bount = 0;

    printf( " Size of Array :");
    scanf( "%d",&b);
    int a[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);
    }


    for (i=0; i<b; i++)
    {
       for ( j=i; j<b ; j++ )
       {
           if( a[i]%2 == 0)
           {

             count++;
             break;

           }
           else
           {
            bount++;
            break;
           }

       }
    }

    printf( " number of even elements is %d :" , count);
    printf( " number of odd elements is %d :" , bount);
   return 0;



}



