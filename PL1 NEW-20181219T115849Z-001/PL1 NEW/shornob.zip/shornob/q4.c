#include <stdio.h>
int main()

{
    int i,j ,b;
    printf( " Enter array size :");
    scanf( "%d",&b);
    int a[b];
    int x[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);
    }
    printf( " After copying values :");
    for(j=0 ; j<b; j++ )
    {
       x[j] = a[j];
       printf( " %d" ,x[j]);
    }



    return 0;





}


