#include <stdio.h>
int main()

{
    int i,j ,b,d ,flag = 0 , flago = 0;

    printf( " Size of Array :");
    scanf( "%d",&b);
    int a[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);

         if(a[i] == i + 1)
        {
            flag = 0;
        }
        else
        {
            flag = 1;
        }
    }

    printf( " Size of Array :");
    scanf( "%d",&d);
    int x[d];
    printf( " Enter values :");
    for (j=0; j<d; j++)
    {
        scanf("%d",&x[j]);

         if(a[j] == j + 1)
        {
            flago = 0;
        }
        else
        {
            flago = 1;
        }
    }


    if( flag == 0)
   {
       printf( " Sorted \n");
   }
    else
  {
      printf ( " Unsorted \n");
  }

   if( flago == 0)
   {
       printf( " Sorted \n");
   }
    else
   {
      printf ( " Unsorted \n");
   }



    return 0;





}



