#include <stdio.h>
int main()

{
    int i,j ,b,d ,count = 0;

    printf( " Size of Array :");
    scanf( "%d",&b);
    int a[b];
    printf( " Enter values :");
    for (i=0; i<b; i++)
    {
        scanf("%d",&a[i]);
    }


    for (i=0; i<b; i++)
    {
       for ( j=i; j<b ; j++ )
       {
           if( a[i] == a[j])
           {

             count++;
             break;

           }
           else
           {
               count = count;
           }

       }
    }

    printf( " Duplicate Number is %d :" , count);

   return 0;



}


