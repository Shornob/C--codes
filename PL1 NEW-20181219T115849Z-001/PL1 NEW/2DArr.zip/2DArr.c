#include<stdio.h>

int main()
{
    //int a[]={1,2,3};
  //int a[3][4]={{3,3,3,4},
            //   {1,1,1,1},
              // {2,5,1,1}};
    int a[3][4];
    int i,j;
   for(i=0;i<3;i++)
    {
        for(j=0;j<4;j++)
        {
            printf("Input at %d , %d :",i,j);
            scanf("%d",&a[i][j]);
        }


    }
    for(i=0;i<3;i++)
    {
        printf("Array row:%d \t",i);
        for(j=0;j<4;j++)
        {
            printf("%d ",a[i][j]);
           // scanf("%d",&a[i,j]);
        }
        printf("\n");


    }
    return 0;
}
