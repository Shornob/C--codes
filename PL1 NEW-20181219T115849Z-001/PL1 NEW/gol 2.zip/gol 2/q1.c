#include <stdio.h>



int main ()

{

    int array[3][4];

    int i, j, m, n, sum = 0 , mul = 1;




    printf("Enter the Values of a  3X4   matrix\n");

    for (i = 0; i < 3; i++)

    {

        for (j = 0; j < 4; j++)

        {

            scanf("%d", &array[i][j]);

        }

    }

    for (i = 0; i < 3; i++)

    {

        for (j = 0; j < 4; j++)

        {

            sum = sum + array[i][j] ;

        }

        printf("Sum of the %d row is = %d\n", i, sum);

        sum = 0;

    }



    for (i = 0; i < 3; i++)

    {

        for (j = 0; j < 4; j++)

        {

            mul =  mul * array[i][j] ;

        }

        printf("Multiplication of the %d row is = %d\n", i, mul);

        mul = 1;

    }



}
