#include <stdio.h>



int main ()

{

    int arr[2][3] , trp[2][3];

    int i, j, m , n   ;




    printf("Enter the Values of a  2X3  1st  matrix\n");

    for (i = 0; i < 2; i++)

    {

        for (j = 0; j < 3; j++)

        {

            scanf("%d", &arr[i][j]);

        }

    }

    printf(" Out put of the input matrix : \n");


    for(i = 0;i < 2; i++)
    {


        for( j = 0 ;j < 3; j++)
        {
            printf("%d ",arr[i][j]);

        }
        printf("\n");

    }






    for (i = 0; i < 2; i++)

    {

        for (j = 0; j < 3; j++)

        {

            trp[j][i] = arr[i][j] ;

        }



    }



   printf(" Transporse of the matrix : \n");


    for(i = 0; i < 3; i++)
    {


        for( j = 0 ;j < 2; j++)
        {
            printf("%d ", trp[i][j]);

        }
        printf("\n");

    }


}

