#include <stdio.h>



int main ()

{

    int arr[3][3] , brr[3][3] , sum[3][3];

    int i, j, m , n   ;




    printf("Enter the Values of a  3X3  1st  matrix\n");

    for (i = 0; i < 3; i++)

    {

        for (j = 0; j < 3; j++)

        {

            scanf("%d", &arr[i][j]);

        }

    }



    printf("Enter the Values of a  3X3  2nd  matrix\n");

    for (m = 0; m < 3; m++)

    {

        for (n = 0; n < 3; n++)

        {

            scanf("%d", &brr[m][n]);

        }

    }







    for (i = 0; i < 3; i++)

    {

        for (j = 0; j < 3; j++)

        {

            sum[i][j] = arr[i][j] + brr[i][j] ;

        }



    }




    for(i = 0;i < 3; i++)
    {
        printf("Array  row:%d \t",i);

        for( j = 0 ;j < 3; j++)
        {
            printf("%d ",sum[i][j]);

        }
        printf("\n");

    }



}

